/*
Module 3 - Lesson 1
-------------------------------------------------------------------------------
*/

function welcome() {
    console.log("Hi");
}
setInterval(welcome, 1000);
